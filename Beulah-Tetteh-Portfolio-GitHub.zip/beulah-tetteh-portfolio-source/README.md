# Beulah Tetteh | Digital Marketing Portfolio

A modern portfolio for Beulah Naa Morkor Tetteh, a digital marketing professional based in Accra, Ghana.

## Included

- Responsive portfolio source
- Project images and personal portrait
- Downloadable CV
- About, expertise, selected work, experience, education and contact sections
- Search-friendly page title and description

## Run locally

Requirements: Node.js 22.13 or newer and npm.

```bash
npm ci
npm run dev
```

Open the local address shown in the terminal.

## Add to GitHub

1. Create a new empty repository on GitHub.
2. Extract this archive and upload its contents to the repository.
3. Commit the files to the main branch.
4. Connect the repository to a host that supports Vinext or Cloudflare Workers.

This project uses Vinext rather than a plain HTML-only GitHub Pages build. The GitHub repository stores and versions the complete source, while a compatible hosting provider builds and serves it.

## Edit the portfolio

- Main content: `app/page.tsx`
- Colours and layout: `app/globals.css`
- Images and CV: `public/portfolio/`
- Page metadata: `app/layout.tsx`

## Production preview

The completed version is available at:

https://beulah-tetteh-portfolio.prinagya25.chatgpt.site
