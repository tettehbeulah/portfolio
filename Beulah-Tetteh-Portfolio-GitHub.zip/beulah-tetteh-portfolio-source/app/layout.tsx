import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Beulah Tetteh | Digital Marketing Professional",
  description:
    "The portfolio of Beulah Tetteh, a digital marketing professional in Accra specialising in content, social media, search and campaign strategy.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
