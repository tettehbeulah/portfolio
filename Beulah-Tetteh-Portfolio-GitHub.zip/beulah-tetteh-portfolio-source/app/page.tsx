import {
  ArrowDownRight,
  ArrowUpRight,
  Download,
  Mail,
  Phone,
  Sparkles,
} from "lucide-react";

const capabilities = [
  {
    number: "01",
    title: "Social media",
    body: "Platform-aware content and campaign ideas for Facebook, Instagram, LinkedIn and X.",
  },
  {
    number: "02",
    title: "Content & copy",
    body: "Clear brand stories, useful editorial content and persuasive copy built around real audience needs.",
  },
  {
    number: "03",
    title: "Search & paid media",
    body: "Foundational SEO and Google Ads thinking that helps brands become easier to find and choose.",
  },
  {
    number: "04",
    title: "Insights & optimisation",
    body: "Performance tracking with Google Analytics and Meta Insights to turn activity into next steps.",
  },
];

const projects = [
  {
    title: "Beulahland Croché",
    type: "Brand strategy · Social content · Entrepreneurship",
    description:
      "A handmade crochet brand shaped from product idea to visual identity, content direction and customer experience.",
    image: "/portfolio/beulahland-crochet.jpg",
    className: "project project-large",
    imageClass: "project-image project-image-crochet",
  },
  {
    title: "Black Suits Me",
    type: "Fashion social creative · Concept",
    description:
      "A monochrome fashion concept using sharp contrast, direct copy and confident visual hierarchy.",
    image: "/portfolio/black-suits-me.png",
    className: "project project-tall",
    imageClass: "project-image project-image-cover",
  },
  {
    title: "Onward with Adventure Co.",
    type: "Travel storytelling · Concept",
    description:
      "An aspirational travel graphic that pairs spacious typography with an emotion-led image.",
    image: "/portfolio/adventure-co.png",
    className: "project project-wide",
    imageClass: "project-image project-image-cover",
  },
  {
    title: "#Connect2Earth",
    type: "Awareness campaign · Concept",
    description:
      "A campaign poster designed to make an environmental message immediate, shareable and action-oriented.",
    image: "/portfolio/connect2earth.png",
    className: "project project-wide project-earth",
    imageClass: "project-image project-image-contain",
  },
];

const experience = [
  {
    period: "May – Aug 2026",
    role: "Digital Marketing Bootcamp Trainee",
    company: "Generation Ghana · Remote",
    description:
      "Built practical foundations across SEO, social media, paid advertising, email and analytics while creating optimised content and insight-led campaign solutions.",
  },
  {
    period: "Dec 2025 – Feb 2026",
    role: "Interviewer",
    company: "CIMG Banking Survey",
    description:
      "Conducted structured interviews with banking customers, recorded accurate survey data and built rapport with a wide range of respondents.",
  },
  {
    period: "Nov 2023 – Oct 2024",
    role: "Insurance Underwriter · National Service",
    company: "Hollard Insurance Ghana Limited",
    description:
      "Reviewed application risk information, analysed customer and policy data, and communicated clearly with clients and internal stakeholders.",
  },
  {
    period: "Oct – Dec 2021",
    role: "Sales Intern",
    company: "Electroland Ghana Limited",
    description:
      "Identified customer needs, explained product benefits and developed an early understanding of customer behaviour through direct sales support.",
  },
];

const education = [
  { year: "2026", course: "Digital Marketing Program", school: "Generation Ghana" },
  { year: "2023 – 2025", course: "BTech Marketing", school: "Accra Technical University" },
  { year: "2020 – 2023", course: "HND Marketing", school: "Accra Technical University" },
  { year: "2016 – 2019", course: "WASSCE", school: "OLA Senior High School" },
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="monogram" href="#top" aria-label="Beulah Tetteh, home">
          BT<span>.</span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#about">About</a>
          <a href="#expertise">Expertise</a>
          <a href="#work">Selected work</a>
          <a href="#experience">Experience</a>
        </nav>
        <a className="header-cta" href="mailto:tettehbeulah@gmail.com">
          Let&apos;s talk <ArrowUpRight size={17} aria-hidden="true" />
        </a>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><span /> Digital marketing professional</p>
          <h1>
            Marketing,
            <br />made <em>human.</em>
          </h1>
          <p className="hero-intro">
            I&apos;m Beulah Tetteh. I turn audience insight, thoughtful content and
            creative strategy into digital experiences people want to engage with.
          </p>
          <div className="hero-actions">
            <a className="button button-dark" href="#work">
              Explore my work <ArrowDownRight size={18} aria-hidden="true" />
            </a>
            <a className="text-link" href="/portfolio/beulah-tetteh-cv.pdf" download>
              <Download size={17} aria-hidden="true" /> Download CV
            </a>
          </div>
        </div>

        <div className="hero-visual">
          <div className="hero-disc" aria-hidden="true">B</div>
          <div className="portrait-frame">
            <img
              src="/portfolio/beulah-tetteh.jpg"
              alt="Beulah Tetteh smiling while seated at a desk"
            />
          </div>
          <div className="availability">
            <span className="status-dot" />
            <span>Open to opportunities<br /><strong>Accra · Remote</strong></span>
          </div>
          <p className="side-note">Strategy / Content / Growth</p>
        </div>
      </section>

      <section className="statement" aria-label="Professional statement">
        <Sparkles size={25} strokeWidth={1.5} aria-hidden="true" />
        <p>
          Creative enough to <em>capture attention.</em><br />
          Analytical enough to <em>make it count.</em>
        </p>
        <span>Based in Ghana<br />Working everywhere</span>
      </section>

      <section className="about section-shell" id="about">
        <div className="section-label">01 / About</div>
        <div className="about-copy">
          <p className="lead">
            I&apos;m a growth-minded marketer who believes the best digital work
            starts by listening closely.
          </p>
          <div className="about-columns">
            <p>
              With a BTech and HND in Marketing, hands-on digital marketing
              training and experience interviewing customers, I bring both
              curiosity and structure to every brief.
            </p>
            <p>
              Building my own crochet brand, Beulahland Croché, has also taught
              me how positioning, content and customer relationships connect in
              the real world. I approach marketing with that same practical care.
            </p>
          </div>
        </div>
      </section>

      <section className="expertise" id="expertise">
        <div className="section-shell">
          <div className="section-heading light-heading">
            <div className="section-label">02 / Expertise</div>
            <h2>Where ideas meet<br /><em>intent.</em></h2>
          </div>
          <div className="capability-list">
            {capabilities.map((item) => (
              <article className="capability" key={item.number}>
                <span>{item.number}</span>
                <h3>{item.title}</h3>
                <p>{item.body}</p>
              </article>
            ))}
          </div>
          <p className="tools-note">
            Working knowledge of Canva, Google Analytics, Search Console,
            Keyword Planner, Mailchimp, Meta Ads Manager and SEO tools.
          </p>
        </div>
      </section>

      <section className="work section-shell" id="work">
        <div className="section-heading work-heading">
          <div className="section-label">03 / Selected work</div>
          <h2>Ideas with a clear<br /><em>point of view.</em></h2>
          <p>
            A mix of brand-building work and creative concepts exploring how
            design, voice and audience insight can work together.
          </p>
        </div>

        <div className="project-grid">
          {projects.map((project, index) => (
            <article className={project.className} key={project.title}>
              <div className="project-media">
                <img
                  className={project.imageClass}
                  src={project.image}
                  alt={`${project.title} project visual`}
                  loading={index === 0 ? "eager" : "lazy"}
                />
                <span className="project-number">0{index + 1}</span>
              </div>
              <div className="project-copy">
                <p>{project.type}</p>
                <h3>{project.title}</h3>
                <span>{project.description}</span>
              </div>
            </article>
          ))}
        </div>

        <article className="content-sample">
          <div className="content-phone">
            <img
              src="/portfolio/content-blog.jpg"
              alt="Mobile article sample about caring for hiking boots"
              loading="lazy"
            />
          </div>
          <div className="content-copy">
            <span>05 / Content marketing sample</span>
            <h3>Useful content begins with a real question.</h3>
            <p>
              A practical editorial sample structured around search intent and
              the questions an outdoor audience is likely to ask. It reflects my
              approach to content: be clear, be useful and make the next step easy.
            </p>
          </div>
          <img
            className="brand-stamp"
            src="/portfolio/beulahland-logo.png"
            alt="Beulahland logo"
            loading="lazy"
          />
        </article>
      </section>

      <section className="experience" id="experience">
        <div className="section-shell">
          <div className="section-heading experience-heading">
            <div className="section-label">04 / Experience</div>
            <h2>A career shaped by<br /><em>curiosity.</em></h2>
          </div>
          <div className="timeline">
            {experience.map((item) => (
              <article className="timeline-row" key={`${item.role}-${item.period}`}>
                <p className="timeline-period">{item.period}</p>
                <div>
                  <h3>{item.role}</h3>
                  <p className="timeline-company">{item.company}</p>
                </div>
                <p className="timeline-description">{item.description}</p>
              </article>
            ))}
          </div>
          <a className="button button-light" href="/portfolio/beulah-tetteh-cv.pdf" download>
            Download full CV <Download size={18} aria-hidden="true" />
          </a>
        </div>
      </section>

      <section className="education section-shell">
        <div className="education-intro">
          <div className="section-label">05 / Education</div>
          <h2>Always learning.<br /><em>Always building.</em></h2>
          <div className="award-card">
            <span>Recognition</span>
            <strong>Outstanding Academic Performance</strong>
            <p>Accra Technical University</p>
          </div>
        </div>
        <div className="education-list">
          {education.map((item) => (
            <article key={`${item.course}-${item.year}`}>
              <span>{item.year}</span>
              <h3>{item.course}</h3>
              <p>{item.school}</p>
            </article>
          ))}
          <div className="additional-learning">
            <span>Additional learning</span>
            <p>Advanced Leadership Skills, Entrepreneurship and Counselling · 2025</p>
            <p>PROMAGS Certificate of Membership · 2023</p>
          </div>
        </div>
      </section>

      <section className="mini-contact">
        <p>Have a brand, audience or idea worth growing?</p>
        <a href="mailto:tettehbeulah@gmail.com">
          Let&apos;s create something meaningful <ArrowUpRight aria-hidden="true" />
        </a>
        <div className="contact-links">
          <a href="mailto:tettehbeulah@gmail.com"><Mail size={17} /> Email</a>
          <a href="tel:+233557446539"><Phone size={17} /> +233 55 744 6539</a>
          <a href="https://www.linkedin.com/in/beulah-tetteh" target="_blank" rel="noreferrer">
            <span className="linkedin-mark" aria-hidden="true">in</span> LinkedIn
          </a>
        </div>
        <footer>
          <span>© 2026 Beulah Naa Morkor Tetteh</span>
          <span>Digital marketing · Accra, Ghana</span>
        </footer>
      </section>
    </main>
  );
}
